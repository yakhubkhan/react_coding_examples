import { useState } from "react";

function App3() {
  const [value, setValue] = useState();
  return (
    <>
      <input type="string" onChange={(e) => setValue(e.target.value)} />
      <div>{value}</div>
    </>
  );
}
export default App3;
