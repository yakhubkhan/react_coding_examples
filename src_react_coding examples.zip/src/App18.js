import Child23 from "./child18";

function App18() {
  const names = [
    { name: "yakhub", age: 34 },
    { name: "sonu", age: 12 },
    { name: "salman", age: 11 },
    { name: "munnu", age: 18 },
  ];
  return (
    <>
      <Child23 list={names} />
    </>
  );
}
export default App18;
