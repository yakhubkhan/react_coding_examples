import React from "react";

const user = [
  { id: "1", name: "yakhub" },
  { id: "2", name: "sonu" },
  { id: "3", name: "salman" },
];
const userItems = user.map((item) => <li key={item.id}>{item.name}</li>);
function App1() {
  return <div>{userItems}</div>;
}
export default App1;
