import { useState } from "react";

function App7() {
  const [num1, setNum1] = useState();
  const [num2, setNum2] = useState();
  const [total, setTotal] = useState(0);
  const add = () => {
    setTotal(num1 + num2);
  };
  return (
    <>
      <div>
        <input type="text" onChange={(e) => setNum1(+e.target.value)} />
        <br />
        <input type="text" onChange={(e) => setNum2(+e.target.value)} />
      </div>
      <div>
        <button onClick={add}>Add two numbers</button>
        <p>Total:{total}</p>
      </div>
    </>
  );
}
export default App7;
