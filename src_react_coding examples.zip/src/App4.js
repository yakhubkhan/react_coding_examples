import { useState } from "react";

function App4() {
  const [value, setValue] = useState();

  return (
    <>
      <h3>Disable Button Challenge</h3>
      <input type="text" onChange={(e) => setValue(e.target.value)} />
      <button disabled={value < 1}>submit</button>
      <div>{value}</div>
    </>
  );
}
export default App4;
