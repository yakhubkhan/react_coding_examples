import { useState } from "react";
function App24() {
  const [town, setTown] = useState([]);
  const city = ["hyd", "bangalore", "chennai"];
  const area = [
    {
      city: "hyd",
      town: "hitect city",
    },
    {
      city: "hyd",
      town: "dilsukhnagar",
    },
    {
      city: "bangalore",
      town: "shivaji nagar",
    },
    {
      city: "bangalore",
      town: "bellandoor",
    },
    {
      city: "chennai",
      town: "cindy",
    },
    {
      city: "chennai",
      town: "merina beach",
    },
  ];
  const onCitySelect = (e) => {
    const cityFilter = area.filter((item) => item.city == e.target.value);
    setTown(cityFilter);
  };
  return (
    <>
      <div>
        <select onChange={(e) => onCitySelect(e)}>
          <option>select</option>
          {city.map((item) => {
            return <option value={item}>{item}</option>;
          })}
        </select>
      </div>
      <br />
      <div>
        <select>
          <option>select </option>
          {town.map((item) => {
            return <option value={item.town}>{item.town}</option>;
          })}
        </select>
      </div>
    </>
  );
}
export default App24;
