import { useState } from "react";

function App5() {
  const [value, setValue] = useState("I need to be updated from my child");
  const updated = () => {
    setValue("parent has been updated");
  };
  return (
    <>
      <div>
        <h2>Parent</h2>
        <p>{value}</p>
      </div>
      <div>
        <h2>Child</h2>
        <button onClick={updated}>Change the parent value</button>
      </div>
    </>
  );
}

export default App5;
