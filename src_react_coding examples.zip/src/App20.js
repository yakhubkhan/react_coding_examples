import React, { useState } from "react";

export default function App20() {
  const [string, Setstring] = useState();

  const Edit = (e) => {
    Setstring(e.target.value);
  };
  const Delete = () => {
    Setstring(" ");
  };

  return (
    <div style={{ textAlign: "center" }}>
      <div>
        <input typr="text" onChange={(e) => Setstring(e.target.value)} />
        <button>Add</button>
      </div>
      <br />
      <div>
        <span>{string}</span>
        <button onClick={Edit}>Edit</button>
        <button onClick={Delete}>Delete</button>
      </div>
    </div>
  );
}
