function Child18(props) {
  return (
    <>
      <table border={1}>
        <tr>
          <th>Name</th>
          <th>Age</th>
        </tr>
        {props.list.map((item) => {
          return (
            <tr>
              <td>{item.name}</td>
              <td>{item.age}</td>
            </tr>
          );
        })}
      </table>
    </>
  );
}
export default Child18;
