import { useState, useEffect } from "react";
import ReactDOM from "react-dom/client";
// import useFetch from "./useFetch";
// import Child from "./child";

const App11 = () => {
  const [data, setData] = useState(null);
  const [name, setName] = useState("");
  const [age, setAge] = useState();
  const [subscribe, setSubscribe] = useState();
  const [location, setLocation] = useState();
  const [gender, setGender] = useState();
  useEffect(() => {
    //  const data=  useFetch('yakhupAp')
  }, [name]);

  const callApi = (namess) => {
    setName(namess);
  };

  const locationList = ["Hydradad", "Bangalore", "Chennai"];

  const onSubmitForm = async (e) => {
    e.preventDefault();
    let obj = {
      name1: name,
      age1: age,
      location1: location,
      gender1: gender,
      subscribe1: subscribe,
    };
    const response = await fetch("test.json", {
      method: "GET", // *GET, POST, PUT, DELETE, etc.
      headers: {
        "Content-Type": "application/json",
        // 'Content-Type': 'application/x-www-form-urlencoded',
      },
      redirect: "follow", // manual, *follow, error
      referrerPolicy: "no-referrer", // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
      // body: JSON.stringify(obj), // body data type must match "Content-Type" header
    });
    return response.json(); // parses JSON response into native JavaScript objects
  };

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <form style={{ marginTop: 30 }}>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Name:
          </div>
          <div>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            ></input>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Age:
          </div>
          <div>
            <input
              type="text"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            ></input>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Subscribe:
          </div>
          <div>
            <input
              type="checkbox"
              value={subscribe}
              onChange={(e) => setSubscribe(e.target.checked)}
            ></input>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Location:
          </div>
          <div>
            <select onChange={(e) => setLocation(e.target.value)}>
              {locationList.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Genger:
          </div>
          <div>
            Male
            <input
              type="radio"
              checked={gender === "Male" ? true : false}
              value="Male"
              onChange={(e) => setGender(e.target.value)}
            ></input>
          </div>
          <div>
            Female
            <input
              type="radio"
              checked={gender === "Female" ? true : false}
              value="Female"
              onChange={(e) => setGender(e.target.value)}
            ></input>
          </div>
        </div>
        <div style={{ justifyContent: "center", display: "flex" }}>
          <button
            onClick={(e) => onSubmitForm(e)}
            style={{ background: "green", color: "white" }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};
export default App11;
