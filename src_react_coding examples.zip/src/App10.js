// import { useEffect, useState } from "react";

// function App10() {
//   const [users, setUsers] = useState([]);

//   useEffect(() => {
//     fetch("https://jsonplaceholder.typicode.com/users")
//       .then((response) => response.json())
//       .then((json) => setUsers(json));
//   });

//   return (
//     <>
//       <table border={1}>
//         <tr>
//           <th>Name</th>
//           <th>Email</th>
//           <th>Phone</th>
//         </tr>
//         {users.map((user) => (
//           <tr>
//             <td>{user.name}</td>
//             <td>{user.email}</td>
//             <td>{user.phone}</td>
//           </tr>
//         ))}
//       </table>
//     </>
//   );
// }

// export default App10;

import { useState, useEffect } from "react";

const App = () => {
  const [data, setData] = useState(null);
  const [name, setName] = useState("");
  const [age, setAge] = useState();
  const [subscribe, setSubscribe] = useState();
  const [location, setLocation] = useState();
  const [gender, setGender] = useState();
  const [locationList, setLocationList] = useState([]);
  const [townList, setTownList] = useState([]);
  const [town, setTown] = useState("");
  useEffect(() => {
    //  const data=  useFetch('yakhupAp')
    fetch("http://localhost:3000/getCity", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((response) => setLocationList(response.data));

    //alert(res.json().message)
  }, []);

  const callApi = (namess) => {
    setName(namess);
  };

  // const locationList = ["Hydradad", "Bangalore", "Chennai"];
  const onLocationChange = (e) => {
    setLocation(e.target.value);
    const name = e.target.value;
    fetch("http://localhost:3000/getTown?name=" + name, {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((response) => setTownList(response.data));
  };
  const onSubmitForm = async (e) => {
    e.preventDefault();
    let obj = {
      name1: name,
      age1: age,
      location1: location,
      gender1: gender,
      subscribe1: subscribe,
    };
    fetch("http://localhost:3000/saveForm", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(obj),
    })
      .then((response) => response.json())
      .then((response) => alert(response.message));

    //alert(res.json().message)
  };

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <form style={{ marginTop: 30 }}>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Name:
          </div>
          <div>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            ></input>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Age:
          </div>
          <div>
            <input
              type="text"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            ></input>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Subscribe:
          </div>
          <div>
            <input
              type="checkbox"
              value={subscribe}
              onChange={(e) => setSubscribe(e.target.checked)}
            ></input>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Location:
          </div>
          <div>
            <select onChange={(e) => onLocationChange(e)}>
              {locationList.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Town:
          </div>
          <div>
            <select onChange={(e) => setTown(e.target.value)}>
              {townList.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "row" }}>
          <div style={{ width: 70, textAlign: "right", paddingRight: 10 }}>
            Genger:
          </div>
          <div>
            Male
            <input
              type="radio"
              checked={gender === "Male" ? true : false}
              value="Male"
              onChange={(e) => setGender(e.target.value)}
            ></input>
          </div>
          <div>
            Female
            <input
              type="radio"
              checked={gender === "Female" ? true : false}
              value="Female"
              onChange={(e) => setGender(e.target.value)}
            ></input>
          </div>
        </div>

        <div style={{ justifyContent: "center", display: "flex" }}>
          <button
            onClick={(e) => onSubmitForm(e)}
            style={{ background: "green", color: "white" }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};
export default App;
