import { useState } from "react";

function App2() {
  const [value, setValue] = useState("I need to update from child");

  const update = () => {
    setValue("parent hasbeen updated");
  };
  return (
    <>
      <div>
        <h2> Parent</h2>
        <p>{value}</p>
      </div>
      <div>
        <h2>child</h2>
        <button onClick={update}>change parent value</button>
      </div>
    </>
  );
}
export default App2;
